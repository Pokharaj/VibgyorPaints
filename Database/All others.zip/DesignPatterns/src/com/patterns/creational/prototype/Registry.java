package com.patterns.creational.prototype;

import java.util.HashMap;

public class Registry {

	private HashMap<String, Item> items = new HashMap<String, Item>();

	public Registry() {
		loadItems();
	}

	public Item createItem(String type) {

		Item item = null;
		try {
			item = (Item) (items.get(type).clone());
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}
		return item;
	}

	private void loadItems() {

		Movie movie = new Movie();
		movie.setTitle("Best movie");
		movie.setPrice(9.99);
		movie.setUrl("http://www.bestmovie.com");
		movie.setRuntime("2 Hours");
		this.items.put("movie", movie);

		Book book = new Book();
		book.setTitle("Harry Porter");
		book.setPrice(11.99);
		book.setUrl("http://www.amazonbooks.com");
		book.setNumberOfPages(320);
		items.put("book", book);
	}
}
