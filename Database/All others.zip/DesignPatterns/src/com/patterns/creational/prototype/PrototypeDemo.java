package com.patterns.creational.prototype;

public class PrototypeDemo {

	public static void main(String[] args) {

		Registry registry = new Registry();
		Movie movie1 = (Movie) registry.createItem("movie");
		movie1.setTitle("New movie title");

		System.out.println(movie1);
		System.out.println(movie1.getPrice());
		System.out.println(movie1.getUrl());
		System.out.println(movie1.getRuntime());

		Movie movie2 = (Movie) registry.createItem("movie");
		movie2.setTitle("New movie title 2");

		System.out.println(movie2);
		System.out.println(movie2.getPrice());
		System.out.println(movie2.getUrl());
		System.out.println(movie2.getRuntime());
	}

}
