package com.patterns.creational.factory;

public class SearchPage extends Page {

}
