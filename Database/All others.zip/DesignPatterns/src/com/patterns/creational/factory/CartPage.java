package com.patterns.creational.factory;

public class CartPage extends Page {

}
