package com.patterns.creational.factory;

public class AboutPage extends Page {

}
