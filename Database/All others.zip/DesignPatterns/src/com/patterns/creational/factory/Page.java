package com.patterns.creational.factory;

public abstract class Page {

}
