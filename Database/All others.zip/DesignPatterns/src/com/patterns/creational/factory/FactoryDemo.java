package com.patterns.creational.factory;

public class FactoryDemo {

	public static void main(String[] args) {

		Website blog = WebsiteFactory.getWebsite("Blog");
		System.out.println(blog.getPages());

		Website shop = WebsiteFactory.getWebsite("Shop");
		System.out.println(shop.getPages());

	}

}
