package com.patterns.creational.factory;

public class CommentPage extends Page {

}
