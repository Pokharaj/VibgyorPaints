package com.patterns.creational.factory;

public class ContactPage extends Page {

}
