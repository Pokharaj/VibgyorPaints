package com.patterns.creational.factory;

public class PostPage extends Page {

}
