import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { CanActivate } from '@angular/router/src/utils/preactivation';
import { routerNgProbeToken } from '@angular/router/src/router_module';

@Injectable({
  providedIn: 'root'
})
export class ProductDetailGuard implements CanActivate {
  path: ActivatedRouteSnapshot[];  route: ActivatedRouteSnapshot;

  constructor(private router: Router) { }

  canActivate(next: ActivatedRouteSnapshot): 
    Observable<boolean> | Promise<boolean> | boolean {

      let id = +next.url[1].path;
      if(isNaN(id) || id < 0) {
        alert('Invalid Product Id');
        this.router.navigate(['/products']);
        return false;
      }
    return true;
  }
}
