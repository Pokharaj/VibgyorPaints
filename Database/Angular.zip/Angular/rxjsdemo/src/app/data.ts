export const books = [
  { id: 1, title: 'Book 1' },
  { id: 2, title: 'Book 2' },
  { id: 3, title: 'Book 3' },
  { id: 4, title: 'Book 4' },
  { id: 5, title: 'Book 5' }
];

export const authers = [
  { id: 1, name: 'Auther 1' },
  { id: 2, name: 'Auther 2' },
  { id: 3, name: 'Auther 3' },
  { id: 4, name: 'Auther 4' },
  { id: 5, name: 'Auther 5' }
];
