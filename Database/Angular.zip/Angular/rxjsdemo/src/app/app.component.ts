import { Component } from '@angular/core';
import { books, authers } from './data';
import { Observable, concat, of, from, fromEvent, Subscriber, interval } from 'rxjs';
import { map, filter } from 'rxjs/operators';

//#region App component
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
}
//#endregion

//#region creating an observable

// function subscribe(subscriber) {
//   books.forEach(value => {
//     subscriber.next(value);
//   });
// }
// const booksObservable$ = new Observable(subscribe);

// booksObservable$.subscribe(data => {
//   console.log(data);
// });

// const authersObservable$ = new Observable(subscriber => {

//   if (document.title !== 'Rxjs Demo') {
//     subscriber.error('Invalid page title');
//   }

//   authers.forEach(value => {
//     subscriber.next(value);
//   });

//   setInterval(() => {
//     console.log('completed');
//   }, 2000);

// });

// authersObservable$.subscribe(
//   data => console.log(data)
// );

//#endregion

//#region of, form, and fromEvent

// const observable1$ = of('string', true, 10, 'another string');

// observable1$.subscribe(data => {
//   console.log(data);
// });

// const observable2$ = from(books);

// observable2$.subscribe(data => {
//   console.log(data);
// });

// concat(observable1$, observable2$).subscribe(data => {
//   console.log(data);
// });

// fromEvent Not wokring
// const button = document.getElementById('readersButton');
// console.log(button);
// fromEvent(button, 'click').subscribe(event => {
//   console.log(event);

//   const div = document.getElementById('dataDiv');
//   books.forEach(book => {
//     div.innerText += book.title + '<br>';
//   });
// });

//#endregion

//#region Subscriber and Observer

// const obs$ = from(books);

// const subscriber = {
//   next: book => console.log('Value: ' + book.title),
//   error: err => console.log('Error: ' + err),
//   complete: () => console.log('Completed')
// };

// obs$.subscribe(subscriber);

// const timestamp$ = new Observable(subscriber => {
//   const timestamp = new Date().toLocaleTimeString();
//   subscriber.next(timestamp);
// });

// timestamp$.subscribe(time => {
//   console.log(time);
// });

// setTimeout(() => {
//   timestamp$.subscribe(time => {
//     console.log(time);
//   });
// }, 1000);

// setTimeout(() => {
//   timestamp$.subscribe(time => {
//     console.log(time);
//   });
// }, 2000);

//#endregion

//#region Cancel subscription

// export class AppComponent {

//   timer$ = interval(1000);

//   sub = this.timer$.subscribe(
//     value => console.log(`${new Date().toLocaleTimeString()} (${value})`),
//     null,
//     () => console.log('completed')
//   );

//   cancel() {
//     this.sub.unsubscribe();
//   }
// }

//#endregion

//#region Using Operators

const booksObservable$ = of(1, 2, 3, 4, 5, 6, 7, 8, 9);

booksObservable$.pipe(
  map(value => value * 3),
  filter(value => value > 5)
).subscribe(value => {
  console.log(value);
});

//#endregion
