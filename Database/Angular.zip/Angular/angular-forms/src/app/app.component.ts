import { Component } from '@angular/core';
import { Employee } from './models/Employee.model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  languages: string[] = [
    'English',
    'Hindi',
    'Kannada'
  ];
  model = new Employee('Pokharaj', 'Patel', true, 'W2', 'Hindi');
}
